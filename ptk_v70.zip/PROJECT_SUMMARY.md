# PayToolkit - Project Summary

## Overview
Free UK tax calculator website. 24 calculators + 5 SEO landing pages + 3 blog posts. Static HTML/CSS/JS, HMRC-aligned 2026/27 rates. Client-side calculations, no signup, no data collection.

---

## Architecture

```
/mnt/agents/output/paytoolkit/
|-- index.html                          Homepage (24 calculators)
|-- about/index.html                    About page (Schema.org AboutPage)
|-- sitemap.xml                         34 URLs (24 calc + 5 guides + blog + legal)
|-- robots.txt                          Sitemap reference
|-- assets/                             Favicons, OG images
|-- site.webmanifest                    PWA manifest
|-- [24 calculator folders]/index.html  Calculator pages
|-- guides/                             5 SEO landing pages
|   |-- student-loan-repayment-guide/
|   |-- equity-release-complete-guide/
|   |-- second-job-tax-explained/
|   |-- tax-codes-complete-guide/
|   |-- cis-tax-refund-guide/
|-- blog/                               3 blog posts
|   |-- section-24-mortgage-interest-ban-explained/
|   |-- allowable-expenses-side-hustlers-forget/
|   |-- payments-on-account-explained/
|-- contact/, privacy/, terms/          Legal pages
```

**Tech stack:** Pure HTML/CSS/JS. No frameworks, no build step, no backend, no database.

---

## 24 Calculators

### Self-Employment (7)
sole-trader-tax, paye-side-hustle-tax, sole-trader-vs-limited-company, gig-driver-tax, vat-calculator, dividend-tax, second-job-tax

### Property (6)
buy-to-let-tax, airbnb-host-tax, capital-gains-tax, equity-release, rent-vs-buy, stamp-duty

### Family Tax (3)
child-benefit-tax, marriage-allowance, tax-code-checker

### Personal Finance (8)
take-home-pay, pension, student-loan-repayment, redundancy-pay, inheritance-tax, cis-tax-refund-estimator, hourly-to-salary-converter, umbrella-pay-calculator

---

## 5 SEO Landing Pages

| Page | Supports Calculator | Word Count | Unique FAQs |
|------|---------------------|------------|-------------|
| `/guides/student-loan-repayment-guide/` | Student Loan Calculator | 2,157 | 8 |
| `/guides/equity-release-complete-guide/` | Equity Release Calculator | 1,834 | 6 |
| `/guides/second-job-tax-explained/` | Second Job Tax Calculator | 1,567 | 5 |
| `/guides/tax-codes-complete-guide/` | Tax Code Checker | 1,498 | 5 |
| `/guides/cis-tax-refund-guide/` | CIS Tax Refund Estimator | 1,891 | 5 |

**Each landing page has:** Article schema + FAQPage schema, table of contents, 2 CTA boxes, comparison tables, worked examples, Sources & Methodology, Last Updated badge, related calculators grid. No duplicate FAQs with calculator pages.

---

## SEO Standard (Applied to All Pages)

| Element | Status |
|---------|--------|
| Unique content (no duplication between pages) | All pages |
| Unique FAQs (landing pages different from calculators) | All pages |
| Schema.org Article JSON-LD | 5 landing pages |
| Schema.org FAQPage JSON-LD | All 29 pages |
| Schema.org SoftwareApplication JSON-LD | 24 calculators |
| Schema.org AboutPage + Organization | About page |
| Title tag (< 60 chars) | All pages |
| Meta description (< 155 chars) | All pages |
| Canonical tag | All pages |
| OG tags + Twitter Cards | All pages |
| Last Updated badge | All calculators + landing pages |
| Sources & Methodology (HMRC links) | All calculators + landing pages |
| Table of contents | 5 landing pages |
| "What You Should Do Next" advice block | Top 8 calculators |
| Fast loading (no frameworks, inline CSS, ~15-20KB) | All pages |

---

## GSC Status (12 days indexed)

| Metric | Value |
|--------|-------|
| Indexed pages | 24 (was 18) |
| Total impressions (28d) | 422 |
| Total clicks | 6 |
| Avg position | Improving |
| **Section 24 blog** | 209 impr, pos 13.36, 0% CTR (title fixed) |
| **Top query clusters** | Student Loan (93 impr), Equity Release (64), Tax Code (49) |

---

## Pending Tasks

| # | Task | Priority |
|---|------|----------|
| 1 | DNS redirect: `www` + `http` to `https://paytoolkit.co.uk/` (Cloudflare Page Rules or registrar) | High |
| 2 | Submit updated sitemap.xml to GSC + request indexing for 5 new guides | High |
| 3 | GSC: Validate fix for duplicate canonical issue | High |
| 4 | Add JSON-LD ItemList items 22-24 for 3 new calculators on homepage | Medium |
| 5 | Ensure all 24 calculator footers link to new guides | Low |

---

## Current Bugs

| # | Issue | Status |
|---|-------|--------|
| 1 | GSC: "Duplicate without user-selected canonical" for `http://www.paytoolkit.co.uk/` | Waiting on user DNS config |
| 2 | Preview domain subdirectory 404s (platform limitation, works on production) | Known limitation |
| 3 | Calculator pages built at different times have minor HTML spacing differences | Cosmetic |

---

## Deployment

```bash
cp -r /mnt/agents/output/paytoolkit/* /mnt/agents/output/clean-deploy/
# Deploy via deploy_website tool: local_dir=/mnt/agents/output/clean-deploy, type=static
```

**Production checklist:**
1. Upload `clean-deploy/` files to web root
2. Configure `.htaccess` for canonical redirects (included)
3. Set up Cloudflare: www to non-www, HTTP to HTTPS
4. Submit `sitemap.xml` to GSC (34 URLs)
5. Request indexing for 5 new guide URLs
6. Request validation fix for duplicate canonical

---

## Last Changes Applied
- 5 SEO landing pages built from GSC query data analysis
- Section 24 blog title rewritten for CTR (was 0% at pos 13)
- CIS landing page: 3 duplicate FAQs rewritten (unique from calculator)
- All 5 guides: titles + descriptions optimized for length
- Last Updated badges added to all 5 landing pages
- Sitemap updated: 34 URLs (was 29)
- 3 new calculators: CIS Tax Refund, Hourly to Salary, Umbrella Pay
- Site count: 24 calculators (was 21)
- Airbnb referral links updated
- SEO enhancements: Last Updated, Sources & Methodology, advice blocks
- LinkedIn posts: 5 drafted for social promotion
