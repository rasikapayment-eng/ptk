#!/usr/bin/env python3
"""
IndexNow URL Submission Script for PayToolkit
Submit all site URLs to Bing and Yandex for instant indexing.

Usage:
    python indexnow-submit.py

This submits all important URLs to Bing's IndexNow API.
Run this after publishing new content or updating existing pages.
"""

import urllib.request
import json
import ssl

# Your IndexNow API key (same as Bing Webmaster verification key)
API_KEY = "c3d9a5cf151645788ad59170e8c38ef9"

# Your domain (change this when you switch to your real domain)
HOST = "paytoolkit.co.uk"

# All URLs to submit (add new pages here as you publish them)
URLS = [
    # Homepage
    f"https://{HOST}/",

    # Core calculators (24 total)
    f"https://{HOST}/take-home-pay-calculator/",
    f"https://{HOST}/sole-trader-tax-calculator/",
    f"https://{HOST}/stamp-duty-calculator/",
    f"https://{HOST}/capital-gains-tax-calculator/",
    f"https://{HOST}/pension-calculator/",
    f"https://{HOST}/dividend-tax-calculator/",
    f"https://{HOST}/vat-calculator/",
    f"https://{HOST}/inheritance-tax-calculator/",
    f"https://{HOST}/tax-code-checker/",
    f"https://{HOST}/buy-to-let-tax-calculator/",
    f"https://{HOST}/student-loan-repayment-calculator/",
    f"https://{HOST}/marriage-allowance-calculator/",
    f"https://{HOST}/child-benefit-tax-calculator/",
    f"https://{HOST}/rent-vs-buy-calculator/",
    f"https://{HOST}/equity-release-calculator/",
    f"https://{HOST}/second-job-tax-calculator/",
    f"https://{HOST}/redundancy-pay-calculator/",
    f"https://{HOST}/gig-driver-tax-calculator/",
    f"https://{HOST}/cis-tax-refund-estimator/",
    f"https://{HOST}/hourly-to-salary-converter/",
    f"https://{HOST}/umbrella-pay-calculator/",
    f"https://{HOST}/paye-side-hustle-tax-calculator/",
    f"https://{HOST}/airbnb-host-tax-calculator/",
    f"https://{HOST}/sole-trader-vs-limited-company-calculator/",

    # Guides (8)
    f"https://{HOST}/guides/student-loan-repayment-guide/",
    f"https://{HOST}/guides/equity-release-complete-guide/",
    f"https://{HOST}/guides/second-job-tax-explained/",
    f"https://{HOST}/guides/tax-codes-complete-guide/",
    f"https://{HOST}/guides/cis-tax-refund-guide/",
    f"https://{HOST}/guides/pension-tax-relief-guide/",
    f"https://{HOST}/guides/stamp-duty-first-time-buyer/",
    f"https://{HOST}/guides/inheritance-tax-thresholds/",

    # Blog posts (5)
    f"https://{HOST}/blog/section-24-mortgage-interest-ban-explained/",
    f"https://{HOST}/blog/allowable-expenses-side-hustlers-forget/",
    f"https://{HOST}/blog/payments-on-account-explained/",
    f"https://{HOST}/blog/5-tax-mistakes-self-employed/",
    f"https://{HOST}/blog/self-assessment-checklist-2026-27/",

    # Comparison pages (2)
    f"https://{HOST}/compare/sole-trader-vs-limited/",
    f"https://{HOST}/compare/rent-vs-buy/",

    # Scotland & Wales (2)
    f"https://{HOST}/scotland/income-tax/",
    f"https://{HOST}/wales/land-transaction-tax/",

    # Downloads (5)
    f"https://{HOST}/downloads/",
    f"https://{HOST}/downloads/tax-year-calendar-2026-27/",
    f"https://{HOST}/downloads/self-assessment-checklist/",
    f"https://{HOST}/downloads/cis-expense-tracker-template/",
    f"https://{HOST}/downloads/tax-rates-quick-reference-card/",

    # Static pages
    f"https://{HOST}/about/",
    f"https://{HOST}/contact/",
]

def submit_to_indexnow(host, key, urls, key_location=None):
    """Submit URLs to IndexNow API (Bing + Yandex)."""
    
    payload = {
        "host": host,
        "key": key,
        "urlList": urls
    }
    
    if key_location:
        payload["keyLocation"] = key_location
    
    data = json.dumps(payload).encode('utf-8')
    
    # Bing IndexNow endpoint
    endpoints = [
        "https://www.bing.com/indexnow",
    ]
    
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    results = []
    for endpoint in endpoints:
        try:
            req = urllib.request.Request(
                endpoint,
                data=data,
                headers={
                    'Content-Type': 'application/json; charset=utf-8',
                    'User-Agent': 'IndexNow-Python/1.0'
                },
                method='POST'
            )
            
            with urllib.request.urlopen(req, context=ctx, timeout=30) as response:
                status = response.status
                body = response.read().decode('utf-8')
                results.append({
                    'endpoint': endpoint,
                    'status': status,
                    'response': body
                })
                print(f"  ✓ {endpoint} → HTTP {status}")
        except Exception as e:
            results.append({
                'endpoint': endpoint,
                'status': 'ERROR',
                'response': str(e)
            })
            print(f"  ✗ {endpoint} → ERROR: {e}")
    
    return results

if __name__ == "__main__":
    print(f"=" * 60)
    print(f"IndexNow URL Submission for {HOST}")
    print(f"=" * 60)
    print(f"Total URLs to submit: {len(URLS)}")
    print()
    
    key_location = f"https://{HOST}/{API_KEY}.txt"
    
    # Submit in batches of 100 (IndexNow limit)
    batch_size = 100
    for i in range(0, len(URLS), batch_size):
        batch = URLS[i:i + batch_size]
        print(f"Submitting batch {i//batch_size + 1}: URLs {i+1}-{min(i+batch_size, len(URLS))}")
        results = submit_to_indexnow(HOST, API_KEY, batch, key_location)
        print()
    
    print("=" * 60)
    print("Submission complete!")
    print(f"Key file: {key_location}")
    print(f"Verify key is accessible: curl {key_location}")
    print("=" * 60)
