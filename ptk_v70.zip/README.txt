PAYTOOLKIT — Complete Site Package (v4)
========================================

FOLDER STRUCTURE
----------------
/
├── .htaccess                           ← Apache config: .uk→.co.uk, HTTPS, caching, security
├── index.html                          ← Homepage
├── sitemap.xml                         ← 16 URLs, submit to Google Search Console
├── robots.txt                          ← Crawler instructions
├── site.webmanifest                    ← Android PWA manifest
├── paytoolkit-cookie-banner-snippet.html ← Paste before </body> on all pages
├── favicon-html-snippet.html           ← Already injected in all pages
├── assets/
│   ├── og-*.jpg (11 files)            ← Social sharing images
│   ├── favicon-*.png (6 files)        ← Browser & mobile icons
├── vat-calculator/                     ← NEW: 152K search volume
├── sole-trader-tax-calculator/
├── paye-side-hustle-tax-calculator/
├── buy-to-let-tax-calculator/
├── sole-trader-vs-limited-company-calculator/
├── student-loan-repayment-calculator/
├── gig-driver-tax-calculator/
├── airbnb-host-tax-calculator/
├── privacy/
├── terms/
├── contact/
├── cookie-policy/
└── blog/
    ├── section-24-mortgage-interest-ban-explained/
    ├── allowable-expenses-side-hustlers-forget/
    └── payments-on-account-explained/

WHAT'S NEW IN V4
----------------
✓ VAT Calculator (8th calculator — 152K monthly search volume)
✓ Production .htaccess with 301 redirects, HTTPS, caching, security headers
✓ Updated sitemap.xml with VAT calculator (priority 0.95)
✓ All 16 pages have favicon tags + affiliate disclosure banners
✓ Cookie Policy page included

DEPLOYMENT
----------
1. Upload entire contents to /public_html/
2. Ensure both .co.uk and .uk domains point to same folder
3. Submit sitemap.xml to Google Search Console
4. Replace affiliate links with your actual tracking URLs
5. Paste cookie banner code before </body> on all pages (optional)

AFFILIATE PROGRAMMES TO APPLY FOR
----------------------------------
• Tide: tide.co/affiliate-programme/ (£50 per account via Impact)
• Starling: starlingbank.com/referral/accountant/ (accountant partnership)
• QuickBooks/Xero: via Awin (backup if FreeAgent declines)
• Awin signup: awin.com (select "Content" as promotional type)

OG IMAGES
---------
All OG image meta tags are set to https://paytoolkit.co.uk/assets/...
If your domain is different, do a find-and-replace on all files.

CONTACT
-------
hello@paytoolkit.co.uk
