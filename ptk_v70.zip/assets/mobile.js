/**
 * Mobile enhancements for PayToolkit calculators
 * - Sticky bottom bar for Calculate button
 * - Auto-scroll to results after calculation
 * - Active state management for sticky bar
 */

(function() {
  'use strict';

  // ===== 1. AUTO-SCROLL TO RESULTS =====
  // After any calculate function runs, smoothly scroll to results
  function scrollToResults() {
    var resultsEl =
      document.querySelector('.results-panel') ||
      document.querySelector('.results') ||
      document.querySelector('#results') ||
      document.querySelector('.calc-result') ||
      document.querySelector('[class*="result"]');

    if (resultsEl && resultsEl.scrollIntoView) {
      // Small delay to let results render first
      setTimeout(function() {
        resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  }

  // Wrap all calculate button clicks
  function attachScrollToButtons() {
    var calcButtons = document.querySelectorAll(
      'button[onclick*="calculate"], ' +
      'button[class*="calc"], ' +
      '.btn-calc, ' +
      'input[type="submit"][class*="calc"]'
    );

    calcButtons.forEach(function(btn) {
      // Don't double-attach
      if (btn.dataset.scrollAttached) return;
      btn.dataset.scrollAttached = 'true';

      btn.addEventListener('click', function() {
        // Wait for calculation to complete, then scroll
        setTimeout(scrollToResults, 200);
      });
    });
  }

  // ===== 2. STICKY BOTTOM BAR =====
  function createStickyBar() {
    // Only on mobile
    if (window.innerWidth > 768) return;
    // Don't create if already exists
    if (document.querySelector('.mobile-sticky-bar')) return;

    // Find the main calculate button
    var mainCalcBtn = document.querySelector('.btn-calc') ||
                      document.querySelector('button[onclick*="calculate"]');
    if (!mainCalcBtn) return;

    var stickyBar = document.createElement('div');
    stickyBar.className = 'mobile-sticky-bar';
    stickyBar.innerHTML =
      '<button class="btn-calc" id="stickyCalcBtn">' + (mainCalcBtn.textContent || 'Calculate') + '</button>' +
      '<button class="btn-secondary" id="stickyTopBtn">Back to Top</button>';

    document.body.appendChild(stickyBar);

    // Sticky calculate button triggers main calculate button
    document.getElementById('stickyCalcBtn').addEventListener('click', function() {
      mainCalcBtn.click();
    });

    // Back to top
    document.getElementById('stickyTopBtn').addEventListener('click', function() {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // ===== 3. ADD NUMERIC KEYBOARD ATTRIBUTES =====
  function enhanceInputs() {
    var inputs = document.querySelectorAll(
      'input[type="number"], ' +
      'input[name*="salary"], ' +
      'input[name*="income"], ' +
      'input[name*="pension"], ' +
      'input[name*="price"], ' +
      'input[name*="amount"], ' +
      'input[name*="gain"], ' +
      'input[name*="rate"]'
    );

    inputs.forEach(function(input) {
      if (!input.hasAttribute('inputmode')) {
        input.setAttribute('inputmode', 'decimal');
      }
      if (!input.hasAttribute('pattern')) {
        input.setAttribute('pattern', '[0-9]*');
      }
    });
  }

  // ===== INIT =====
  function init() {
    attachScrollToButtons();
    createStickyBar();
    enhanceInputs();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Re-run on resize (in case orientation changes)
  var resizeTimer;
  window.addEventListener('resize', function() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {
      createStickyBar();
    }, 250);
  });

})();
